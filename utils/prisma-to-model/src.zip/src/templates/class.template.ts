export const CLASS_TEMPLATE = `#!{IMPORTS}

#!{DECORATORS}
export class #!{NAME} {
#!{FIELDS}
}
#!{EXTRA}
`
