export interface Echoable {
	echo(): void
}
